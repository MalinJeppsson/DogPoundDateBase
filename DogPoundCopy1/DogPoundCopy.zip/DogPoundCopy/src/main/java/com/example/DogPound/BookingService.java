package com.example.DogPound;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;


@Service
public class BookingService {

    @Autowired

    BookingRepository repository;

    public List<Booking> getDataWithJPA(User user) {

        // todo use JPA to return a list of movies with a price over 42 and ordered by price descending
        List<Booking> bookings = repository.findByUserOrderByStartDateTimeDesc(user);

        return bookings;
    }
}
