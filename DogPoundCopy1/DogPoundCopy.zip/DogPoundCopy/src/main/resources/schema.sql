
  CREATE TABLE Accounts (
  	Id BIGINT AUTO_INCREMENT,
  	OwnerName nvarchar(50) NOT NULL,
  	OwnerLastName nvarchar(50) NOT NULL,
  	Email nvarchar(70) NOT NULL,
  	Password nvarchar(50) NOT NULL,
  	PhoneNumber nvarchar(20) NULL,
  	DogName nvarchar(50) NOT NULL,
  	DogWeight nvarchar(50) NULL,
  	DogBreed nvarchar(50) NULL,
  	SpecialNeeds nvarchar(240) NULL
  );

CREATE TABLE Booking(
  	Id BIGINT AUTO_INCREMENT,
  	StartDateTime datetime NOT NULL,
  	EndDateTime datetime NOT NULL,
  	UserId int NOT NULL
);