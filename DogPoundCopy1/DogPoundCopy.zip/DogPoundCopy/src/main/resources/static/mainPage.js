function myFunction() {

  const el = document.querySelector(".ourChatBox");
  el.remove()

}}