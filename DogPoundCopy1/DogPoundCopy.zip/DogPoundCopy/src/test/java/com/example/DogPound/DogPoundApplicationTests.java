package com.example.DogPound;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.util.Assert;

@SpringBootTest
class DogPoundApplicationTests {
	/*UserRepository repository = new UserRepository();

	@Test
	public void contextLoads() {
	}
    @Test
	public void deleteUser(){
		//Arrange
		User testuser = new User("Mallan","Jeppsson","mallan@j.se","Tass", "123456789", "Maze","9", "Pug","Food alergy");
		//Act
		Assert.isTrue(repository.userRepository.size() == 1, "");
		repository.addUser(testuser);
		Assert.isTrue(repository.userRepository.size() == 2, "");
		repository.deleteUser(testuser);
		//Assert
		Assert.isTrue(repository.userRepository.size() == 1, "");
	}
    @Test
	public void addUser(){
		//Arrange
		User testuser = new User("Mallan","Jeppsson","mallan@j.se","Tass", "123456789", "Maze","9", "Pug","Food alergy");
		//Act
		Assert.isTrue(repository.userRepository.size() == 1, "");
		repository.addUser(testuser);
		//Assert
		Assert.isTrue(repository.userRepository.size() == 2, "");
	}*/

}
